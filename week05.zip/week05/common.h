typedef struct _test_struct{
    char name[1024];
    unsigned age;
    char group[1024];
} test_struct_t;


typedef struct result_struct_{
	char message[4096];
} result_struct_t;
