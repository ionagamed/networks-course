# How to build

Using CMake:
    $ cmake .
    $ make