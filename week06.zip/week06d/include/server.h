#ifndef _SERVER_H
#define _SERVER_H

int server_main(unsigned short listen_port);

#endif