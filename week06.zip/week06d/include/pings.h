#ifndef _PINGS_H
#define _PINGS_H

void ping_all_nodes();

#endif
