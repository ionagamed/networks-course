#ifndef _GLOBALS_H
#define _GLOBALS_H

#include "node.h"

#define BUFFER_SIZE 20480

extern unsigned short listen_port;
extern char node_name[NODE_NAME_LEN];
extern int ping_interval;

#endif
