#ifndef _BOOTSTRAP_H
#define _BOOTSTRAP_H

int bootstrap_known_nodes(char * bootstrap_ip, unsigned short bootstrap_port, unsigned short listen_port);

#endif
